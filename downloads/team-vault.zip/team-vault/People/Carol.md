---
color: "#79b58d"
team: "Example Project"
---

# Carol

Team member on [[Example Project]].

To see work assigned to this person, open this note and run **Show tasks assigned to this note**, or use **Show tasks assigned to a person** from the command palette.
